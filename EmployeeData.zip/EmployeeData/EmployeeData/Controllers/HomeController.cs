﻿using EmployeeData.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using BOL;
using BLL;
namespace EmployeeData.Controllers

{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddEmployee()
        {
            Employee employee = new Employee();
            bool status = false;
            this.ViewBag.mystatus = status;
            return View(status);
        }
        [HttpPost]
        public IActionResult AddEmployee(int id, string firstName, string lastName, string email, string pass2, int age)
        {
            Employee employee = new Employee();
            EmployeeManager manager = new EmployeeManager();
            employee = new Employee { Id = id, FirstName = firstName, LastName = lastName, Email=email, Pass2 = pass2, Age = age };
            bool status = manager.AddEmployee(employee);
            this.ViewBag.myStatus = status;
            return RedirectToAction("GetAllEmployee"); ;
        }

        public IActionResult UpdateEmployee() {
            Employee employee = new Employee();
            bool status = false;
            this.ViewBag.mystatus = status;
            return View(status);
        }

        [HttpPost]
        public IActionResult UpdateEmployee(int id, string firstName, string lastName, string email, string pass2, int age)
        {
            Employee employee = new Employee();
            EmployeeManager manager = new EmployeeManager();
            employee = new Employee { Id = id, FirstName = firstName, LastName = lastName, Email = email, Pass2 = pass2, Age = age };
            bool status = manager.AddEmployee(employee);
            this.ViewBag.myStatus = status;
            return RedirectToAction("GetAllEmployee");
        }

        public IActionResult Login() {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string email,string password)
        {
            bool flag = false;
            EmployeeManager manager = new EmployeeManager();
            List<Employee> list = manager.GetAllEmployees();
            
            Console.WriteLine(password);
            
            foreach (Employee emp in list) {
                
                if (emp.Email.Equals(email) && emp.Pass2.Equals(password))
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            if (flag)
            {
                return RedirectToAction("GetAllEmployee");
            }
            else { 
                return View();
            }
            
            
        }

        public IActionResult GetAllEmployee() 
        {
            EmployeeManager manager = new EmployeeManager();
            List<Employee> list = manager.GetAllEmployees();
            this.ViewBag.myList = list;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}