﻿using DAL;
using BOL;
namespace BLL

{
    public class EmployeeManager
    {
        public bool AddEmployee(Employee emp) { 
                DbManager manage = new DbManager();
                return manage.AddEmployee(emp);

        }

        public List<Employee> GetAllEmployees() {
            DbManager manage = new DbManager();
            List<Employee> list = manage.GetAllEmployees();
            return list;
        }

    }
}