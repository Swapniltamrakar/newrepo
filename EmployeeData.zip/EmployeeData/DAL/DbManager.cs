﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using BOL;
namespace DAL
{
    public class DbManager
    {
        public static string conString = @"server=localhost;port=3306;user=root; password=Swap@1998;database=dotnet";
        public List<Employee> GetAllEmployees() {

            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = conString;
            List<Employee> allEmployees = new();
            try
            {
                con.Open();
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = con;
                string query = "SELECT * FROM employee";
                cmd.CommandText = query;
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    int id = int.Parse(reader["id"].ToString());
                    string name = reader["firstName"].ToString();
                    string lname = reader["lastName"].ToString();
                    string email = reader["email"].ToString();
                    int age = int.Parse(reader["age"].ToString());
                    string password = reader["pass2"].ToString();

                    Employee emp = new Employee
                    {
                        Id = id,
                        FirstName = name,
                        LastName = lname,
                        Email = email,
                        Age = age,
                        Pass2 = password
                    };
                    allEmployees.Add(emp);
                }
            }
            catch (Exception ee)
            {
                Console.WriteLine(ee.Message);
            }
            finally
            {
                con.Close();
            }

            return allEmployees;
        }

        public bool AddEmployee(Employee emp)
        {
            bool status = false;
            MySqlConnection con = new MySqlConnection();
            con.ConnectionString = conString;
           
            try
            {
                con.Open();
                string query = $"INSERT INTO employee VALUES({emp.Id},'{emp.FirstName}','{emp.LastName}','{emp.Email}','{emp.Pass2}',{emp.Age})";
                MySqlCommand cmd = new MySqlCommand(query,con);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                status = true;
               
            }
            catch (Exception ee)
            {
                Console.WriteLine(ee.Message);
            }
            finally
            {
                con.Close();
            }

            return status;
        }
         
        public bool UpdateEmployee(Employee emp)
        {
            bool status = false;
            MySqlConnection conn = new MySqlConnection();
            conn.ConnectionString = conString;
            try {
                string query = $"Update employee set firstName = '{emp.FirstName}',lastName ='{emp.LastName}',email='{emp.Email}',age={emp.Age} where id = {emp.Id}";
                MySqlCommand cmd = new MySqlCommand( query,conn);
                cmd.Connection = conn;
                cmd.ExecuteNonQuery();
                status= true;
            }
            catch (Exception ee)
            {
                Console.WriteLine(ee.Message);
            }
            finally
            {
                conn.Close();
            }

            return status;
        }




    }
}
