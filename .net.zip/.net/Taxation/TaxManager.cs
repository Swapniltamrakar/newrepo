﻿namespace Taxation
{
    public class TaxManager
    {

        public double IncomeTax(double salary) {

            salary =salary-salary * 0.15;
            return salary;
        }

        public double ServiceTax(double salary) {
            salary = salary - salary * 0.10;
            return salary;
        }

        public double ProfessionalTax(double salary)
        {
            salary = salary - salary * 0.05;
            return salary;
        }

    }
}