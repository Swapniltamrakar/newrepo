﻿
using Employee;

Console.WriteLine("WELCOME");

Boolean flag = true;
List<Emoloyee> list = new();
int id = 0;
while (flag)
{
    
    int choice = 0;
    Console.WriteLine("Enter a Chioce : \n1.Add an employee\n2.Display all Employee\n3.Display Companies expenditure\n0.exit");
    choice = int.Parse(Console.ReadLine());
    switch (choice)
    {
        case 1:

            Console.WriteLine("Enter FirstName,LastName,Email,Age,Id,Salary,Type");
            list.Add(
                new Emoloyee(
                      firstName: Console.ReadLine(),
                lastName: Console.ReadLine(),
                email: Console.ReadLine(),
                age: int.Parse(Console.ReadLine())
                , _id: int.Parse(Console.ReadLine()), sal: double.Parse(Console.ReadLine()), empType: Console.ReadLine().ToUpper())
                    );
            Console.WriteLine("Employee added successfully");
            break;

        case 2:
            foreach (Emoloyee e in list)
            {
                Console.WriteLine(e);
            }
            break;
        case 3:
            double exp = 0;
            foreach (Emoloyee e in list)
            {
                exp = exp + e.InHandSal;
            }
            Console.WriteLine($"Total Company Expenditure : {exp}");
            break;

        case 4:
            Console.WriteLine("Enter id : ");
            id = int.Parse(Console.ReadLine());
            foreach (Emoloyee e in list)
            {
                if (e.Id == id)
                {
                    Console.WriteLine(e);
                }
                else
                {
                    Console.WriteLine("NOT FOUND");
                }
            }
            break;
        case 0:
            Console.WriteLine("ThankYou");
            flag = false;
            break;

    }

}