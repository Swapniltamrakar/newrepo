﻿
using System.Collections;
using Taxation;
namespace Employee
{
    public class Emoloyee : Person
    {

        public enum depart {MANGER,SALES}



        private int id;
        public depart t;
        public int Id { get { return this.id; } set { this.id = value; } }
        private double salary { set; get;}

        private double inHandSal;

       /* private Emoloyee emp;
        public Emoloyee this[int index] {
            get { return this.emp[index]; }
            set { this.emp[index] = value; }
        }
       */
        public double InHandSal
        {
            get { return this.inHandSal; }
            set { this.inHandSal = value;}
        }

        public Emoloyee(string firstName, string lastName, string email, int age,int _id,double sal,String empType) : base(firstName, lastName, email, age)
        {


            depart.TryParse(empType, out t);
            TaxManager tx = new TaxManager();
            this.salary = sal;

            if (t.Equals(depart.MANGER))
            {
                TaxOperation tax1 = new TaxOperation(tx.ProfessionalTax);
                sal = tax1(sal);
                TaxOperation tax2 = new TaxOperation(tx.IncomeTax);
                sal = tax2(sal);

            }
            else
            { 
                TaxOperation tax2 = new TaxOperation(tx.IncomeTax);
                sal = tax2(sal);
                TaxOperation tax3 = new TaxOperation(tx.ServiceTax);
                sal = tax3(sal);

            }
            this.id = _id;
            this.inHandSal=sal;
            
        }

        public override string ToString()
        {
            return $"{base.ToString()} , ID : {this.id} , Salary : {this.salary} , Type : {this.t}";
        }
    }
}