﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public abstract class Person
    {

        private string firstName { get; set; }
        private string lastName { get; set; }
        private string email { get; set; }
        private int age { get; set; }

        public Person(String firstName,String lastName,String email,int age) { 
        this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
            this.age = age;
        
        } 

        public override string ToString()
        {
            return $"First Name : {this.firstName} , LastName : {this.lastName} , Email : {this.email} , Age : {this.age} ";

        }


    }
}
